#pragma once
class MyOctant
{
};

